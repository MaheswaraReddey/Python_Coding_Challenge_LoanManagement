from .Loan import Loan
class CarLoan(Loan):
    def __init__(self, LoanID, CustomerID, PrincipalAmount, InterestRate, LoanTerm, CarModel, CarValue):
        super().__init__(LoanID, CustomerID, PrincipalAmount, InterestRate, LoanTerm, 'CarLoan', 'Pending')
        self.CarModel = CarModel
        self.CarValue = CarValue

    # Getter methods
    def getLoanID(self):
        return self.LoanID

    def getCarModel(self):
        return self.CarModel

    def getCarValue(self):
        return self.CarValue

    # Setter methods
    def setLoanID(self, LoanID):
        self.LoanID = LoanID

    def setCarModel(self, CarModel):
        self.CarModel = CarModel

    def setCarValue(self, CarValue):
        self.CarValue = CarValue
