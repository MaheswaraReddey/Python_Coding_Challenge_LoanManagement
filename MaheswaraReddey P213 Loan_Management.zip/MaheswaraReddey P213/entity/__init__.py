from .Customer import Customer
from .Loan import Loan
from .HomeLoan import HomeLoan
from .CarLoan import CarLoan
